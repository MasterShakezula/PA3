#include<stdlib.h>
#include<string.h>
#include<stdio.h> 
#define _GNU_SOURCE     